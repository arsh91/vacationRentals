<?php

include 'db_connection.php';
include 'vacationIcs.php';

$ticketNumber = $_POST['ticketNum'];
$teamMemberNo = $_POST['teamMembersNo'];

$ticketData = $db->query('SELECT * FROM MaintenanceTicket WHERE TicketNum= ?', $ticketNumber)->fetchArray();

$PropertyAddress = $db->query('SELECT * FROM Properties WHERE PropertyName= ?', $ticketData['Property'])->fetchArray();
$address = $PropertyAddress['Address'] .', '. $PropertyAddress['City'] . ', '. $PropertyAddress['State'] . ', '. $PropertyAddress['Zip'];

// GET THE MEMBER DATA NEED TO PRINT IN TICKET AFTER CLOSED
if($ticketData['ClosedBy']){
$teamMemberData = $db->query('SELECT * FROM Team WHERE TeamMemberID = ?', $ticketData['ClosedBy'])->fetchArray();
}

if($ticketData['ETATeamMemberID'] > 0){
$teamMemberName = $db->query('SELECT * FROM Team WHERE TeamMemberID = ?' , $ticketData['ETATeamMemberID'])->fetchArray();
}

$teamAdminData = $db->query('SELECT admin FROM Team WHERE TeamMemberID = ?' ,$teamMemberNo)->fetchArray();
?>

<section class="ticket_datils">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p><span class="titleStyle"> Property Name: </span><?= $ticketData['Property']; ?> </p>
                <p><span class="titleStyle"> Urgency: </span><?= $ticketData['Urgency']; ?> </p>
                <p><span class="titleStyle"> Issue: </span><?= $ticketData['Issue']; ?> </p>
                <p><span class="titleStyle"> Issue Description:
                    </span><?= $ticketData['IssueDescription']; ?>
                </p>
                <p><span class="titleStyle">First Name: </span><?= $ticketData['FirstName']; ?> </p>
                <p><span class="titleStyle"> Phone: </span><?= $ticketData['Phone']; ?> </p>
                <p><span class="titleStyle"> Ticket Date:
                    </span><?= date("m-d-Y", strtotime($ticketData['TicketDate']) ); ?> </p>
                <p><span class="titleStyle"> Ticket Time:
                    </span><?= date("h:i A", strtotime($ticketData['TicketTime']) ); ?> </p>
                <p><span class="titleStyle"> Ticket Number:
                    </span><span class="ticket_id"><?= $ticketData['TicketNum']; ?> </span></p>
                <p><span class="titleStyle"> Address:
                    </span>
                    <a target="_blank" href="https://www.google.com/maps/place/<?php echo
                            str_replace(' ', '+', $address);?>">
                        <?= $address;
                        ?> </a>
                </p>
                <p><span class="titleStyle"> Gate code:
                    </span><?= $PropertyAddress['GateCode']; ?>
                </p>
                <p class="doorcode">
                </p>
                <?php
                                if($ticketData['ETATeamMemberID'] > 0 && $teamMemberName['ReleaseDoorCode'] == "Y"){
                                    ?>
                <p><span class="titleStyle"> Door code:
                    </span><?= $PropertyAddress['DoorCode']; ?>
                </p>

                <?php
                                }
                                $file = $PropertyAddress['ical'];
                                $obj = new ics();
                                $icsEvents = $obj->getIcsEventsAsArray( $file );
                                
                                    unset( $icsEvents [1] );
                                    $checkOutDate = "";
                                    $table_html = '<table class="table table-bordered table-striped"><thead><tr><th> Event </th><th> Check In </th><th> Check Out </th></tr></thead><tbody>';
                                    foreach( $icsEvents as $icsEvent){
                                        $start = isset( $icsEvent ['DTSTART;VALUE=DATE'] ) ? $icsEvent ['DTSTART;VALUE=DATE'] : $icsEvent ['DTSTART'];
                                        $startDt = new DateTime ( $start );
                                        $startDate = $startDt->format ( 'm/d/Y h:i' );
                                        $end = isset( $icsEvent ['DTEND;VALUE=DATE'] ) ? $icsEvent ['DTEND;VALUE=DATE'] : $icsEvent ['DTEND'];
                                        $endDt = new DateTime ( $end );
                                        $endDate = $endDt->format ( 'm/d/Y h:i' );
                                        $eventName = $icsEvent['SUMMARY'];
                                        $table_html .= '<tr><td>'.$eventName.'</td><td>'.date('Y-m-d',strtotime($startDate)).'</td><td>'.date('Y-m-d',strtotime($endDate)).'</td></tr>';
                                        $current_date = date("m/d/Y h:i");
                                          if(strtotime($startDate) < strtotime($current_date) && strtotime($endDate) > strtotime($current_date) ) {
                                        //    $checkOutDate= date('m/d/Y h:i',strtotime(' + 1 day ',strtotime($endDate)));
                                        $checkOutDate = date("m-d-Y", strtotime($endDate));
                                            }
                                }
                                $table_html.='</tbody></table>';
                                ?>
                                <p><span class="titleStyle"> Next Check Out Date: </span><span> 
                                <?php 
                                if(!empty($checkOutDate)){
                                    echo $checkOutDate;
                                }
                                ?>
                                    </span>
                                </p>
                                <p><span class="titleStyle"> Calendar:
                                    </span><span><a data-toggle="collapse" href="#collapse_reservedTable" role="button" aria-expanded="false" aria-controls="collapseExample">Click here</a></span>
                                </p>
                                <div class="collapse" id="collapse_reservedTable">
                                    <div class="reserved_table" style="max-height: 300px;overflow: hidden;overflow-y: scroll;margin-bottom: 15px;">
                                    <?php echo $table_html; ?>
                                    </div>
                                </div>
                                


                <?php if($ticketData['ClosedDate'] != "" || $ticketData['ClosedDate'] != NULL) { ?>
                <p><span class="titleStyle"> Ticket Closed Date:
                    </span><?= $ticketData['ClosedDate']; ?> </p>
                <p><span class="titleStyle"> Ticket Closed Time:
                    </span><?= $ticketData['ClosedTime']; ?> </p>
                <p><span class="titleStyle"> Ticket Closed By:
                    </span><?= $teamMemberData['Fname']." ". $teamMemberData['Lname']; ?> </p>
                <p><span class="titleStyle"> Notes:
                    </span><?= $ticketData['Notes']; ?> </p>
                <?php } if($ticketData['ETATeamMemberID'] == 0) {?>
                <div>
                    <p><span class="titleStyle">Assigned to:</span><span class="assignedTo"> Unassigned
                            Ticket
                        </span></p>
                    <p><span class="titleStyle">ETA:</span><span class="etaDateTime"> Unassigned
                            Ticket
                        </span> </p>
                </div>
                <?php $teamMemberNo = $_SESSION['user']['TeamMemberID'];?>
                <div class="eta-radio-container" id="eta_container">
                    <div class="form-check">
                        <input class="teammember" type="hidden" teamMemberId=<?php echo $teamMemberNo;?>>
                        <input class="form-check-input radiobutton" type="radio" value="resolve_2_hours"
                            name="eta_radio" id="resolve_2_hours" data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_2_hours">
                            I can resolve within 2 hours
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio" value="resolve_4_hours"
                            name="eta_radio" id="resolve_4_hours" data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_4_hours">
                            I can resolve within 4 hours
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio" value="resolve_today_10am"
                            name="eta_radio" id="resolve_today_10am"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_today_10am">
                            I can resolve today by 10 AM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio" value="resolve_today_12noon"
                            name="eta_radio" id="resolve_today_12noon"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_today_12noon">
                        I can resolve today by 12 NOON
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                            value="resolve_today_2pm" name="eta_radio" id="resolve_today_2pm"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_today_2pm">
                        I can resolve today by 2 PM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                            value="resolve_today_6pm" name="eta_radio" id="resolve_today_6pm"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_today_6pm">
                        I can resolve today by 6 PM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                        value="resolve_today_9pm" name="eta_radio" id="resolve_today_9pm"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_today_9pm">
                        I can resolve today by 9 PM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                            value="resolve_tomorrow_10am" name="eta_radio" id="resolve_tomorrow_10am"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_tomorrow_10am">
                        I can resolve tomorrow by 10 AM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                            value="resolve_tomorrow_12noon" name="eta_radio" id="resolve_tomorrow_12noon"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_tomorrow_12noon">
                        I can resolve tomorrow by 12 NOON
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                            value="resolve_tomorrow_2pm" name="eta_radio" id="resolve_tomorrow_2pm"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_tomorrow_2pm">
                        I can resolve tomorrow by 2 PM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                            value="resolve_tomorrow_6pm" name="eta_radio" id="resolve_tomorrow_6pm"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_tomorrow_6pm">
                        I can resolve tomorrow by 6 PM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio"
                            value="resolve_tomorrow_9pm" name="eta_radio" id="resolve_tomorrow_9pm"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_tomorrow_9pm">
                        I can resolve tomorrow by 9 PM
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio" value="resolve_nextturn"
                            name="eta_radio" id="resolve_nextturn" data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="resolve_nextturn">
                            I can resolve at next turn
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input radiobutton" type="radio" value="unable_resolve"
                            name="unable_resolve_eta_radio" id="unable_resolve"
                            data-id=<?php echo $ticketData['TicketNum']; ?>>
                        <label class="form-check-label" for="unable_resolve">
                            Unable/unwilling to resolve
                        </label>
                    </div>
                </div>
                <div class="assigned_msg">

                </div>

                <?php }else {?>
                <div>
                    <p><span class="titleStyle">Assigned to:</span>
                        <?php echo $teamMemberName['Fname']." ". $teamMemberName['Lname']; ?> </p>
                    <p><span class="titleStyle">ETA:</span>
                        <?php echo date("m-d-Y", strtotime($ticketData['ETADate']) )." ".date("h:i A", strtotime($ticketData['ETATime']) ); ?>
                    </p>

                    <?php }?>
                </div>

                <?php if($teamAdminData['admin'] == 'Y' && $ticketData['Feedbackrequested'] == NULL){?>
                        <div class="form-group requestFeedbackBtn pt-2">
                            <button type="submit" teamMemberId=<?php echo $teamMemberNo;?> name="requestFeedbackBtn" id="requestFeedbackBtn" value="requestFeedbackBtn" class="btn btn-primary requestFeedback">Request Feedback</button>
                        </div>
                <?php } elseif($teamAdminData['admin'] == 'Y' && $ticketData['Feedbackrequested'] != NULL) { ?>
                        <div class='form-group pt-2'>
                            <p><span class="titleStyle">Feedback Requested :</span>
                            <span><?php echo date("m-d-Y h:i A", strtotime($ticketData['Feedbackrequested']) ); ?>
                            </span>
                            </p>
                        </div>
                <?php } ?>
                <div class='form-group feedbackDateTime pt-2' style="display:none;">
                    <p><span class="titleStyle">Feedback Requested :</span>
                    <span class="showFeedbackData"></span>
                    </p>
                </div>
                <div class="assigned_feedback"></div>

                <div id="assigned_membername"></div>

                <div class="container">
                    <div class="row">
                        <?php if($ticketData['Pic1'] != "" ){?>
                        <div class="col-md-6 mt-2 p-0">
                            <div class="text-center">
                                <img src="https://wecare.equisourceholdings.com/<?= $ticketData['Pic1']; ?>" alt=""
                                    width="200px">
                            </div>
                        </div>
                        <?php } if($ticketData['Pic2'] != "" ){ ?>
                        <div class="col-md-6 mt-2 p-0">
                            <div class="text-center">
                                <img src="https://wecare.equisourceholdings.com/<?= $ticketData['Pic2']; ?>" alt=""
                                    width="200px">
                            </div>
                        </div>
                        <?php } if($ticketData['Pic3'] != "" ){ ?>
                        <div class="col-md-6 mt-2 p-0">
                            <div class="text-center">
                                <img src="https://wecare.equisourceholdings.com/<?= $ticketData['Pic3']; ?>" alt=""
                                    width="200px">
                            </div>
                        </div>
                        <?php } if($ticketData['Pic4'] != "" ){ ?>
                        <div class="col-md-6 mt-2 p-0">
                            <div class="text-center">
                                <img src="https://wecare.equisourceholdings.com/<?= $ticketData['Pic4']; ?>" alt=""
                                    width="200px">
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="//code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
    crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
</script>

<script type="text/javascript">
$(document).ready(function() {


 
    $('#requestFeedbackBtn').click(function() {
       
            var ticket_id = $('.ticket_id').text();
            var teamMemberId = $('.requestFeedback').attr('teamMemberId');
            $.ajax({
                type: "POST",
                url: "vacationRequestFeedbackEmail.php",
                data: {
                    'TicketNum': ticket_id,
                    'teamMemberId': teamMemberId
                    },
                    success: function(response) {

                        var response = JSON.parse(response);
                        if (response.Feedbackrequested) {
                        
                        $('.requestFeedbackBtn').hide();
                        $('.feedbackDateTime').show();

                        $('.showFeedbackData').html(" " +response.Feedbackrequested);
                    }
                    
                    $('.assigned_feedback').append(
                        '<div class="alert alert-success mt-3 feedback_success_msg" role="alert"> Feedback requested Successfully!</div>'
                    );
                    setTimeout(() => {
                        $('.feedback_success_msg').fadeOut('slow');
                    }, 2000);

                    }
            });


    });

    $('input[name=eta_radio]').click(function() {
        var ticket_id = $('.ticket_id').text();
        var teamMemberId = $('.teammember').attr('teamMemberId');
        var eta_radio = $(this).val();

        $.ajax({
            type: "POST",
            url: "openTicketEtaUpdate.php",
            data: {
                'TicketNum': ticket_id,
                'eta_radio': eta_radio,
                'teamMemberId': teamMemberId
            },
            success: function(response) {

                var response = JSON.parse(response);
                //console.log(response);
                if (response.doorCode) {
                    $(".doorcode").html("<span class='titleStyle'>" + " Door code:" +
                        "</span>" + " " + response.doorCode);
                }

                if (response.teamMemberName) {
                    $('.assignedTo').html(" " + response.teamMemberName);
                }

                if (response.etaDateTime) {
                    $('.etaDateTime').html(" " + response.etaDateTime);
                }

                $('.assigned_msg').append(
                    '<div class="alert alert-success mt-3 eta_success_msg" role="alert">Ticket ETA Updated Successfully!</div>'
                );
                setTimeout(() => {
                    $('.eta_success_msg').fadeOut('slow');
                }, 2000);
                $('#eta_container').hide();

                // setTimeout((function() {
                //     window.location.reload();
                // }), 3000);
                // $('div#assigned_membername').html(
                //     "<p class='text-center' style='font-weight:bold; font-size:16px ;'>This ticket has been assigned to you </p>"
                // );
            }
        });
    });

});
</script>